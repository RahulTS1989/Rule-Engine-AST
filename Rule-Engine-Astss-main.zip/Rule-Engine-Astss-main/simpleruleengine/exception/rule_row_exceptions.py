class RuleRowNotEvaluatedException(Exception):
    pass
